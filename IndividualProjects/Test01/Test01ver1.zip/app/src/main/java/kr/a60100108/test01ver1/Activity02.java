package kr.a60100108.test01ver1;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class Activity02 extends AppCompatActivity {
    public static int i; //글로벌 변수

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_02);
        Intent goto2 = getIntent();
        i = goto2.getIntExtra("key2", 0);
        TextView tv = (TextView) findViewById(R.id.textView);
        tv.setText(String.valueOf(i));
    }
    public void gotoActivity3(View view){
        Intent goto3 = new Intent(this, Activity03.class);

        goto3.putExtra("key3", i+1);
        startActivity(goto3);
    }
    public void gotoActivity4(View view){
        Intent goto4 = new Intent(this, Activity04.class);

        goto4.putExtra("key4", i-1);
        startActivity(goto4);
    }
    public void gotoHome(View view){
        Intent gotohome = new Intent("kr.a60100108.test01ver1.gotohome");

        PackageManager packageManager = getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(gotohome, 0);
        boolean isIntentSafe = activities.size() > 0;

        if (isIntentSafe){
            gotohome.putExtra("key1", i);
            startActivity(gotohome);
        }
    }
}
