package kr.a60100108.test01ver1;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class Activity04 extends AppCompatActivity {
    public static int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_04);
        Intent goto4 = getIntent();
        i = goto4.getIntExtra("key4", 0);
        TextView tv = (TextView) findViewById(R.id.textView);
        tv.setText(String.valueOf(i));
    }
    public void gotoActivity2(View view){
        Intent goto2 = new Intent(this, Activity02.class);

        goto2.putExtra("key2", i+1);
        startActivity(goto2);
    }
    public void gotoActivity3(View view){
        Intent goto3 = new Intent(this, Activity03.class);

        goto3.putExtra("key3", i-1);
        startActivity(goto3);
    }
    public void gotoHome(View view){
        Intent gotohome = new Intent("kr.a60100108.test01ver1.gotohome");

        PackageManager packageManager = getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(gotohome, 0);
        boolean isIntentSafe = activities.size() > 0;

        if (isIntentSafe){
            gotohome.putExtra("key1", i);
            startActivity(gotohome);
        }
    }
}
