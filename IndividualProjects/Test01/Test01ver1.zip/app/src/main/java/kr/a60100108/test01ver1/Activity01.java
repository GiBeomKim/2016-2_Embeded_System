package kr.a60100108.test01ver1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Activity01 extends AppCompatActivity {
    public static int num, i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_01);
        Intent intent = getIntent();
        i = intent.getIntExtra("key1", 0);
        TextView tv = (TextView) findViewById(R.id.finalView);
        tv.setText(String.valueOf(i));
    }

    public void gotoActivity2(View view){
        Intent goto2 = new Intent(this, Activity02.class);
        EditText et = (EditText) findViewById(R.id.editText);
        num = Integer.parseInt(et.getText().toString());
        goto2.putExtra("key2", num-1);
        startActivity(goto2);
    }

    public void gotoActivity4(View view){
        Intent goto4 = new Intent(this, Activity04.class);
        EditText et = (EditText) findViewById(R.id.editText);
        num = Integer.parseInt(et.getText().toString());
        goto4.putExtra("key4", num+1);
        startActivity(goto4);
    }

}
