package kr.a60100108.test02_app3;



public class FeedReaderContract {
}
