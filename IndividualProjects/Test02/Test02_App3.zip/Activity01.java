package kr.a60100108.test02_app3;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class Activity01 extends AppCompatActivity {

    public static final String CONTENT_URI = "content://kr.a60100108.test02_app1ver1/60100108DB";
    public static final String CONTENT_NAME = "name";
    public static final String CONTENT_SCORE = "score";
    public static final String ID = "_id";
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_01);

        lv = (ListView)findViewById(R.id.listView);
        ContentResolver cr = getContentResolver();
        Cursor c = cr.query(Uri.parse(CONTENT_URI), null, null, null, null);
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_2,
                c, new String[] {CONTENT_NAME, CONTENT_SCORE}, new int[] {android.R.id.text1, android.R.id.text2});
        lv.setAdapter(adapter);
    }
}
