package kr.a60100108.test02_app1ver1;


import android.provider.BaseColumns;

public final class FeedReaderContract {
    public FeedReaderContract(){};

    public static final String DATABASE_NAME = "60100108DB.db";
    public static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + FeedEntry.TABLE_NAME + " ( " +
                    FeedEntry._ID + " INTEGER PRIMARY KEY," +
                    FeedEntry.COLUMN_NAME_NAME + " text , " +
                    FeedEntry.COLUMN_NAME_SCORE + " int " + " ) ";

    public static final String SQL_DELETE_TABLE =
            "DROP TABLE IF EXISTS " + FeedEntry.TABLE_NAME;

    public static abstract class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME = "Test_table";
        public static final String COLUMN_NAME_NAME = "name";
        public static final String COLUMN_NAME_SCORE = "score";
    }
}
