package kr.team02.driver;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import java.util.List;

public class MainSchedule extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);
        Intent intent = getIntent();
    }
    public void gotoHome(View view){
        Intent gotohome = new Intent("kr.team02.driver.gotohome");

        PackageManager packageManager = getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(gotohome, 0);
        boolean isIntentSafe = activities.size() > 0;

        if (isIntentSafe){
            startActivity(gotohome);
        }
    }
}
