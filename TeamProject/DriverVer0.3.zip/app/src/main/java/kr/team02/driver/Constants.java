package kr.team02.driver;


public class Constants {
    public static final String PROJECT_NUM = "806788649966";
    public static final String API_KEY = "AIzaSyAVUu2EB8NZ0W0BBDbVTsI52fT-Yo-a0LU";
    public static String REG_ID = "APA91bEo45L0LzeKwAxjx2rU86MCFCq4VXYasQVHSHVPdrLi1GgXKL9Saz6TyZKuiYIFthFusPxQLvYUwLfCVjp8gMcJAte3TR1iOFhiukshWvrxTQwAIAHrfwk1tM3zPnI8IIHx0bLW";
}
