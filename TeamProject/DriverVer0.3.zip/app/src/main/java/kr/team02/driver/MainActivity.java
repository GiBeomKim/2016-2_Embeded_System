package kr.team02.driver;

import android.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.DialogPreference;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.PermissionChecker;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gcm.server.MulticastResult;
import com.google.android.gcm.server.Sender;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;


import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity implements LocationListener {
    private GoogleApiClient mGoogleApiClient;;
    GoogleCloudMessaging gcm;
    Sender sender;
    ArrayList<String> clientList = new ArrayList<String>();
    String gps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String context = Context.LOCATION_SERVICE;
        LocationManager locationManager = (LocationManager) getSystemService(context);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            alertCheckGPS();
        }
    }

    private void alertCheckGPS() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("위치 서비스가 꺼져있습니다.\n원할한 서비스를 위해 켜주시길 바랍니다.")
                .setCancelable(false)
                .setPositiveButton("GPS 활성화",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                moveConfigGPS();
                            }
                        })
                .setNegativeButton("취소",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    // GPS 설정화면으로 이동
    private void moveConfigGPS() {
        Intent gpsOptionsIntent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(gpsOptionsIntent);
    }


    public void pressGPS(View v) {

        String[] permissions = new String[]{android.Manifest.permission.INTERNET, android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.ACCESS_FINE_LOCATION};
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
            for(String permission:permissions) {
                int result = PermissionChecker.checkSelfPermission(this, permission);
                if(result==PermissionChecker.PERMISSION_GRANTED) ;
                else {
                    ActivityCompat.requestPermissions(this, permissions, 1);
                }
            }
        }

        if (Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            return;

        Location mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            //GPS 정보 받기
            gps = String.valueOf(mLastLocation.getLatitude()+" "+mLastLocation.getLongitude());
            //gps = String.valueOf("GiBeom"+" "+"Kim");
        }

        LocationRequest request = new LocationRequest();
        request.setInterval(10000);
        request.setFastestInterval(5000);
        request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, request, this);

        clientList.clear();
        clientList.add(Constants.REG_ID);
        sender = new Sender(Constants.API_KEY);
        new SendMsgTask().execute(null, null, null);
    }

    @Override
    public void onLocationChanged(Location location){
        gps = String.valueOf(location.getLatitude()+" "+location.getLongitude());
    }

    class SendMsgTask extends AsyncTask<Void, Void, String> {
        @Override
        protected void onPreExecute() { }

        @Override
        protected String doInBackground(Void... params) {
            String str;
            try {
                com.google.android.gcm.server.Message.Builder msgbuilder = new com.google.android.gcm.server.Message.Builder();
                Random random = new Random(System.currentTimeMillis());
                String messageCollapseKey = String.valueOf(Math.abs(random.nextInt()));
                msgbuilder.collapseKey(messageCollapseKey).delayWhileIdle(true).timeToLive(60);
                msgbuilder.addData("gps", URLEncoder.encode(gps, "UTF-8"));
                com.google.android.gcm.server.Message msg = msgbuilder.build();
                MulticastResult result = sender.send(msg, clientList, 2);
                str = result.getMulticastId()+ "," + result.getRetryMulticastIds() + "," + result.getSuccess();
            } catch (IOException e) {
                str = "Error in sending message" + e.getMessage();
            }
            return str;
        }


        @Override
        protected void onPostExecute(String msg) { }
    }

    @Override
    protected void onPause(){
        super.onPause();
        LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addApi(LocationServices.API)
                    .build();
        }
        mGoogleApiClient.connect();
    }

    @Override
    protected void onStop() {
        if (mGoogleApiClient != null) {
            mGoogleApiClient.disconnect();
        }
        super.onStop();
    }

}
