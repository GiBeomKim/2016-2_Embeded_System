package kr.team02.customer;


public class Constants {
    public static final String PROJECT_NUM = "806788649966";
    public static String REG_ID = "";
}
