package kr.team02.customer;


import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.util.StringTokenizer;


public class MainActivity extends AppCompatActivity {
    private GoogleApiClient mGoogleApiClient;
    GoogleCloudMessaging gcm;
    public String gps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        startActivity(new Intent(this, LoadingActivity.class));
        //if(intent != null) intentHandler(intent);

    }

    public void pressButton1(View view){
        Intent schedule = new Intent(this, MainSchedule.class);
        startActivity(schedule);
    }
    public void pressButton2(View view){
        Intent map = new Intent(this, MapsActivity.class);

        new RegisterTask().execute(null,null,null);
        Intent intent = getIntent();
        intentHandler(intent);
        startActivity(map);
    }

    public void pressbutton3(View view){
        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.mju.ac.kr/mbs/mjukr/index.jsp"));
        startActivity(i);
    }

    class RegisterTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            String str;
            try {
                if (gcm == null) gcm = GoogleCloudMessaging.getInstance(getApplicationContext());
                Constants.REG_ID = gcm.register(Constants.PROJECT_NUM);
                Log.i("REG","ID :"+Constants.REG_ID);
                str = "Device registered, registration ID is\n" + Constants.REG_ID;
            } catch (IOException e) {
                str = "Error in registration:" + e.getMessage();
            }
            return str;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        intentHandler(intent);
        super.onNewIntent(intent);
    }

    public void intentHandler(Intent intent) {
        gps = intent.getStringExtra("gps");
        Log.i("gps","Received gps: " + gps);
        Intent intentGps = new Intent(this, MapsActivity.class);
        intentGps.putExtra("gps", gps);
        startActivity(intentGps);

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addApi(LocationServices.API)
                    .build();
        }
        mGoogleApiClient.connect();
    }
    @Override
    protected void onStop() {
        if (mGoogleApiClient != null) {
            mGoogleApiClient.disconnect();
        }
        super.onStop();
    }

}
