package kr.team02.customer;


public class FeedReaderContract {
}
