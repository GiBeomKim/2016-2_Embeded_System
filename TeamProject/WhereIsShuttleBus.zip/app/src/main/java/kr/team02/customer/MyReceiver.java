package kr.team02.customer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;

import java.net.URLDecoder;

public class MyReceiver extends WakefulBroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if ((action != null) && (action.equals("com.google.android.c2dm.intent.RECEIVE"))) {

            String gps = intent.getStringExtra("gps");
            //String longitude = intent.getStringExtra("longitude");

            String data = "";
            //String data2 = "";
            try {
                data = URLDecoder.decode(gps, "UTF-8");
                //data2 = URLDecoder.decode(longitude, "UTF-8");
            } catch(Exception ex) { ex.printStackTrace(); }

            Intent tmpintent = new Intent(context, MainActivity.class);
            tmpintent.putExtra("gps",data);
            //tmpintent.putExtra("longitude",data2);
            tmpintent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            context.startActivity(tmpintent);
        }
    }
}
