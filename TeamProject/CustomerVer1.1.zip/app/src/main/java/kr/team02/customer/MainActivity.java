package kr.team02.customer;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
    }

    public void pressButton1(View view){
        Intent schedule = new Intent(this, MainSchedule.class);
        startActivity(schedule);
    }
    public void pressButton2(View view){
        Intent map = new Intent(this, MapsActivity.class);
        startActivity(map);
    }
}
