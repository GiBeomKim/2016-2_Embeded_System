package kr.team02.customer;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        Intent intent = getIntent();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng loc_mju = new LatLng(37.222275, 127.1862);

        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        UiSettings mapSettings;
        mapSettings = mMap.getUiSettings();
        mapSettings.setZoomControlsEnabled(true);
        mapSettings.setCompassEnabled(true);
        mapSettings.setIndoorLevelPickerEnabled(true);
        mapSettings.setMapToolbarEnabled(true);
        mapSettings.setScrollGesturesEnabled(true);
        mapSettings.setTiltGesturesEnabled(true);
        mapSettings.setRotateGesturesEnabled(true);
        mapSettings.setMyLocationButtonEnabled(true);
        Marker mju = mMap.addMarker(new MarkerOptions()
                .position(loc_mju)
                .title("현재 버스 위치"));
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(loc_mju)
                .zoom(15)
                .tilt(15)
                .build();
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

        GroundOverlayOptions BusStop00 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //출발지
                .position(new LatLng(37.224295, 127.187688), 30f, 20f);
        mMap.addGroundOverlay(BusStop00);

        GroundOverlayOptions BusStop01 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //e마트(하행) 버스정류장
                .position(new LatLng(37.231709, 127.188417), 30f, 20f);
        mMap.addGroundOverlay(BusStop01);

        GroundOverlayOptions BusStop01_1 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //e마트(상행) 버스정류장
                .position(new LatLng(37.231373, 127.188151), 30f, 20f);
        mMap.addGroundOverlay(BusStop01_1);

        GroundOverlayOptions BusStop02 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //진입로(하행) 버스정류장
                .position(new LatLng(37.234254, 127.188832), 30f, 20f);
        mMap.addGroundOverlay(BusStop02);

        GroundOverlayOptions BusStop02_1 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //진입로(하행) 버스정류장
                .position(new LatLng(37.233886, 127.188578), 30f, 20f);
        mMap.addGroundOverlay(BusStop02_1);

        GroundOverlayOptions BusStop03 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //에버라인 명지대역
                .position(new LatLng(37.238192, 127.189880), 30f, 20f);
        mMap.addGroundOverlay(BusStop03);

        GroundOverlayOptions BusStop04 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //에버라인 명지대역
                .position(new LatLng(37.238192, 127.189880), 30f, 20f);
        mMap.addGroundOverlay(BusStop04);

        GroundOverlayOptions BusStop05 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //중앙지구대앞
                .position(new LatLng(37.234726, 127.198160), 30f, 20f);
        mMap.addGroundOverlay(BusStop05);

        GroundOverlayOptions BusStop06 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //롯데시네마마앞
                .position(new LatLng(37.235368, 127.206319), 30f, 20f);
        mMap.addGroundOverlay(BusStop06);

        GroundOverlayOptions BusStop07 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //중앙공영주차장앞
                .position(new LatLng(37.233641, 127.208897), 30f, 20f);
        mMap.addGroundOverlay(BusStop07);

        GroundOverlayOptions BusStop08 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //창조관 건너편
                .position(new LatLng(37.222060, 127.188978), 30f, 20f);
        mMap.addGroundOverlay(BusStop08);

        GroundOverlayOptions BusStop09 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //1공학관 건너편
                .position(new LatLng(37.222627, 127.186526), 30f, 20f);
        mMap.addGroundOverlay(BusStop09);

        GroundOverlayOptions BusStop10 = new GroundOverlayOptions()
                .image(BitmapDescriptorFactory.fromResource(R.drawable.hbus))
                //3공학관
                .position(new LatLng(37.219395, 127.183093), 30f, 20f);
        mMap.addGroundOverlay(BusStop10);



    }
}
