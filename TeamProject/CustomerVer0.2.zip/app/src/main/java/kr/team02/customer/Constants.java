package kr.team02.customer;


public class Constants {
    public static final String PROJECT_NUM = "293593180085";
    public static String REG_ID = "";
}
